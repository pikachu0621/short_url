create view score_view as
select `testb`.`score`.`stu_id`   AS `stu_id`,
       `testb`.`score`.`stu_name` AS `stu_name`,
       `testb`.`score`.`chinese`  AS `chinese`,
       `testb`.`score`.`math`     AS `math`,
       `testb`.`score`.`english`  AS `english`
from `testb`.`score`;

